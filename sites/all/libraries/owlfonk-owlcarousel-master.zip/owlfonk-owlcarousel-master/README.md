This is just an alias repo, since the official repo looks down. (https://github.com/OwlFonk/OwlCarousel)

### Documentation ###
for documentation, please head to the official doc.
https://www.npmjs.com/package/owlcarousel

#### Note
Copyrights reserved with the owner. (https://github.com/OwlFonk/OwlCarousel)
